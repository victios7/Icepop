# 📋 Guía — Crear el EXE desde tu PC (sin GitHub)

---

## Lo que necesitas instalar primero

### 1. Node.js
Descárgalo desde:
👉 https://nodejs.org

Elige la versión **LTS** (la recomendada). Instálalo con todas las opciones por defecto.

Para comprobar que se instaló bien, abre una terminal y escribe:
```
node --version
```
Debe mostrar algo como `v20.x.x` o superior.

---

## PASO 1 — Descomprime la carpeta

Descomprime el ZIP que descargaste. Verás esta estructura:

```
IcepopIDE-release/
├── .github/
├── src/
│   └── IcepopIDE_v2.html
├── main.js
├── package.json
└── ...
```

---

## PASO 2 — Abre una terminal dentro de la carpeta

**Opción A (recomendada):**
- Abre la carpeta `IcepopIDE-release` en el Explorador de archivos
- Haz clic en la barra de direcciones de arriba
- Escribe `cmd` y pulsa Enter

**Opción B:**
- Abre el menú Inicio
- Escribe `cmd` y abre la terminal
- Escribe:
  ```
  cd C:\ruta\a\la\carpeta\IcepopIDE-release
  ```
  (cambia la ruta a donde descomprimiste el ZIP)

---

## PASO 3 — Instalar dependencias

En la terminal escribe:

```
npm install
```

Esto descargará Electron y electron-builder automáticamente.
Puede tardar **2-5 minutos** la primera vez. Es normal que imprima mucho texto.

---

## PASO 4 — Construir el EXE

```
npm run dist
```

Esto compilará el EXE. Tarda **3-8 minutos** dependiendo de tu PC.

Verás que imprime líneas como:
```
  • electron-builder  version=24.x.x
  • packaging        platform=win32 arch=x64
  • building         target=nsis
  ...
  • build            success
```

---

## PASO 5 — Encontrar el EXE

Cuando termine, abre la carpeta `dist/` dentro de `IcepopIDE-release`.

Encontrarás:
- **`IcepopIDE Setup 2.0.0.exe`** → instalador completo (crea acceso directo)
- **`IcepopIDE-v2-Portable.exe`** → ejecuta directamente sin instalar

---

## PASO 6 — Ejecutar

Haz doble clic sobre cualquiera de los dos `.exe`.

Si Windows muestra un aviso de seguridad:
1. Haz clic en **"Más información"**
2. Luego en **"Ejecutar de todas formas"**

Es normal en aplicaciones sin firma digital.

---

## PASO 7 — Usar la IA (Ollama)

Para que la inteligencia artificial funcione, **antes de abrir el IDE** abre una terminal aparte y ejecuta:

```
OLLAMA_ORIGINS=* ollama serve
```

O en Windows también puedes usar el archivo `launch ollama.bat` disponible en el repositorio oficial.

---

## Resumen de comandos

```
npm install
npm run dist
```

Solo esos dos. El EXE estará en la carpeta `dist/`.

---

## Si algo falla

| Error | Solución |
|---|---|
| `npm: command not found` | Instala Node.js desde https://nodejs.org y reinicia la terminal |
| `Error: EACCES` o permisos | Ejecuta la terminal como Administrador |
| El proceso se queda parado | Espera, puede tardar varios minutos |
| `Cannot find module 'electron'` | Ejecuta `npm install` de nuevo |
| El EXE no abre | Prueba el Portable en vez del instalador |

---

## Solo quiero probar sin compilar

Si no quieres compilar nada, también puedes abrir el IDE directamente:

1. Entra en la carpeta `src/`
2. Abre `IcepopIDE_v2.html` con **Google Chrome** o **Microsoft Edge**

Funciona igual, sin necesidad de instalar nada.

---

> BOM STUDIOS · IcepopIDE v2
